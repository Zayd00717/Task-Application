document.addEventListener('DOMContentLoaded', function () {
  const taskForm = document.getElementById('taskForm');
  const taskInput = document.getElementById('task');
  const assignedToInput = document.getElementById('assignedTo');
  const taskList = document.getElementById('tasks');

  let tasks = [];
  let editMode = false;
  let editIndex = -1;

  const submitButton = document.getElementById('submitButton');
  const updateButton = document.getElementById('updateButton');

  // submitting
  taskForm.addEventListener('submit', function (event) {
      event.preventDefault();

      const task = taskInput.value.trim();
      const assignedTo = assignedToInput.value.trim();

      const newTask = { task, assignedTo };

      if (editMode && editIndex !== -1) {
          tasks[editIndex] = newTask;
          editMode = false;
          editIndex = -1;
          submitButton.style.display = 'inline-block';
          updateButton.style.display = 'none';
      } else {
          tasks.push(newTask);
      }

      renderTasks();
      taskForm.reset();
  });

  // Function to render tasks
  function renderTasks() {
      taskList.innerHTML = '';

      tasks.forEach((task, index) => {
          const li = document.createElement('span');
          li.classList.add('task-item');
          li.innerHTML = `
              <div class="container4" data-index="${index}">
                  <a class="a2">Task: <strong>${task.task}</strong></a><br class="br">
                  <a class="a22">Assigned To: <strong>${task.assignedTo}</strong></a>
                  <button class="a3" data-index="${index}">DELETE</button>
              </div>
          `;
          taskList.appendChild(li);
      });
  }

  // Edit task and delete button
  taskList.addEventListener('click', function (event) {
      if (event.target.classList.contains('a3')) {
          const index = event.target.dataset.index;
          deleteTask(index);
      }

      if (event.target.closest('.container4')) {
          const index = event.target.closest('.container4').dataset.index;
          editTask(index);
      }
  });

  // Functioning delete button
  function deleteTask(index) {
      tasks.splice(index, 1);
      renderTasks();
      taskForm.reset()
      submitButton.style.display = 'inline-block';
      updateButton.style.display = 'none';
  }

  // Functioning of updating a task
  function editTask(index) {
      editMode = true;
      editIndex = index;
      const { task, assignedTo } = tasks[index];
      taskInput.value = task;
      assignedToInput.value = assignedTo;
      submitButton.style.display = 'none';
      updateButton.style.display = 'inline-block';
  }

  // Event listener for update button
  updateButton.addEventListener('click', function () {
      if (editMode && editIndex !== -1) {
          const task = taskInput.value.trim();
          const assignedTo = assignedToInput.value.trim();

          tasks[editIndex] = { task, assignedTo };

          editMode = false;
          editIndex = -1;
          submitButton.style.display = 'inline-block';
          updateButton.style.display = 'none';
          taskForm.reset();
          renderTasks();
      }
  });

  // Function for 'Add New' button
  window.addNewTask = function () {
      taskForm.reset();
      editMode = false;
      editIndex = -1;
      submitButton.style.display = 'inline-block';
      updateButton.style.display = 'none';
  };
});